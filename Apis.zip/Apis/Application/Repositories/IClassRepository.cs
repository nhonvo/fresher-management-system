﻿using Domain.Entities;

namespace Application.Repositories
{
    public interface IClassRepository : IGenericRepository<TrainingClass>
    {
    }
}
