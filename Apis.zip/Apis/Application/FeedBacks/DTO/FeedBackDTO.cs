﻿namespace Application.FeedBacks.DTO
{
    public class FeedBackDTO
    {
        public int Rating { get; set; }
        public string Comment { get; set; }
        public int UserId { get; set; }
    }
}
