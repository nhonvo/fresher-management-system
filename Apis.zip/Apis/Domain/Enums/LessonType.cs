﻿namespace Domain.Enums
{
    public enum LessonType
    {
        Online = 0,
        Offline = 1
    }
}
