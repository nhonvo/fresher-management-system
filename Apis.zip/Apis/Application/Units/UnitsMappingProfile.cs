﻿using Application.Units.Commands.CreateUnit;
using Application.Units.Commands.UpdateUnit;
using Application.Units.DTO;
using AutoMapper;
using Domain.Entities;

namespace Application.Units
{
    public class UnitsMappingProfile : Profile
    {
        public UnitsMappingProfile()
        {
            CreateMap<Unit, UnitDTO>().ReverseMap();
            CreateMap<Unit, CreateUnitCommand>().ReverseMap();
            CreateMap<Unit, UpdateUnitCommand>().ReverseMap();
        }
    }
}
