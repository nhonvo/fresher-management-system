﻿namespace Application.Interfaces
{
    public interface IClaimService
    {
        public int CurrentUserId { get; }
    }
}
