namespace Domain.Enums
{
    public enum AttendanceStatus
    {
        Present,
        Absent,
        NoExcuse,
        InLate,
        OutEarly
    }
}
