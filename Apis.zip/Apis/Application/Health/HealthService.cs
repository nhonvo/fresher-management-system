﻿namespace Application.Health;

public class HealthService
{
    public bool IsHealthy { get; private set; } = true;
}