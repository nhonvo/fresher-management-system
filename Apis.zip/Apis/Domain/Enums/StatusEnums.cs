﻿namespace Domain.Enums
{
    public enum StatusEnums
    {
        Good,
        Bad,
        Out,
        OnTrack
    }
}
