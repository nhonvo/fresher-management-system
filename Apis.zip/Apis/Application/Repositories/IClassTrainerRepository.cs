using Domain.Entities;

namespace Application.Repositories
{
    public interface IClassTrainerRepository : IGenericRepository<ClassTrainer>
    {
    }
}
