﻿using CoreApiResponse;
using Microsoft.AspNetCore.Mvc;

namespace WebAPI.Controllers
{
    [Route("api/[controller]/")]
    [ApiController]
    public class CustomBaseController : BaseController
    {
    }
}
