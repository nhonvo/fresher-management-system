namespace Application.Class.DTO
{
    public class TrainerClassDTO
    {
        public int TrainingClassId { get; set; }
        public int TrainerId { get; set; }
    }

}
