﻿namespace Application.Interfaces
{
    public interface ICurrentTime
    {
        public DateTime GetCurrentTime();
    }
}
