﻿namespace Domain.Enums
{
    public enum TestAssessmentType
    {
        Quiz = 0,
        Assignment = 1,
        FinalTheory = 2,
        FinalPractice = 3
    }
}
