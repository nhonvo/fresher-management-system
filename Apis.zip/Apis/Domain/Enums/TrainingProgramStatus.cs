﻿namespace Domain.Enums
{
    public enum TrainingProgramStatus
    {
        Active = 0,
        Inactive = 1
    }
}
