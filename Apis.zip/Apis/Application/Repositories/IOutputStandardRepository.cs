using Domain.Entities;

namespace Application.Repositories;

public interface IOutputStandardRepository : IGenericRepository<OutputStandard>
{
}
