﻿using Domain.Entities;

namespace Application.Repositories
{
    public interface IFeedBackrepository : IGenericRepository<FeedBack>
    {
    }
}
