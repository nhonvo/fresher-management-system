﻿//using Application.Commons;
//using Application.TestAssessments.DTO;
//using Application.ViewModels.TestAssessmentViewModels;
//using AutoMapper;
//using Domain.Entities;

//namespace Application.Mapper
//{
//    public class TestAssessementProfile : Profile
//    {
//        public TestAssessementProfile()
//        {
//            CreateMap<TestAssessmentViewModel, TestAssessment>().ReverseMap();
//        }
//    }
//}
