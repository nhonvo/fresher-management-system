﻿namespace Domain.Enums;

public enum SortingOrder
{
    None,
    Ascending,
    Descending
}
