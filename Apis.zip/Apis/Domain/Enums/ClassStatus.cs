﻿namespace Domain.Enums
{
    public enum ClassStatus
    {
        Planning = 0,
        Opening = 1,
        Closed = 2
    }
}
