using Microsoft.AspNetCore.Mvc;

namespace WebAPI.Controllers
{
    [Route("api/[controller]/")]
    [ApiController]
    public class BasesController : ControllerBase
    {
    }
}