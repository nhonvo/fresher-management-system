﻿using Domain.Entities;

namespace Application.Repositories
{
    public interface IUnitLessonRepository : IGenericRepository<UnitLesson>
    {
    }
}
