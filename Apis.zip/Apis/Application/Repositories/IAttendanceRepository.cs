// using Domain.Entities;

// namespace Application.Repositories
// {
//     public interface IAttendanceRepository : IGenericRepository<Attendance>
//     {
//     }
// }
