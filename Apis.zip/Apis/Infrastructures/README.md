# Infrastructures

This layer is responsible for the infrastructure of the application.
It contains: configuration, database, external services, security, etc...
