namespace Application.OutputStandards.DTO;

#pragma warning disable
public class OutputStandardDTO
{
    public int Id { get; set; }
    public string Code { get; set; }
    public string Description { get; set; }
}
